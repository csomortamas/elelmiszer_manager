/**
 * Load a given termek from the database
 */

module.exports = function(objectrepository) {
    return function(req, res, next) {
        console.log("getTermekMW")
        next()
    }
}