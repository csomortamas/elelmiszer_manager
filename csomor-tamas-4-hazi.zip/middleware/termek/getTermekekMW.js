/**
 * Load all termek from a tarolo from the database
 */

module.exports = function(objectrepository) {
    return function(req, res, next) {
        console.log("getTermekekMW")
        next()
    }
}