/**
 * Load all tarolo from the database
 */

module.exports = function(objectrepository) {
    return function(req, res, next) {
        console.log("getTarolokMW")
        next()
    }
}