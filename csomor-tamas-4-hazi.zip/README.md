# Élelmiszer manager
